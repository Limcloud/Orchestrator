function Handler($context, $inputs) {

    try {
        $ErrorActionPreference = "Stop"

        $manifest = Get-ChildItem `
            -Path $PSScriptRoot `
            -Filter "ImportExcel.psd1" `
            -Recurse |
            Select-Object -First 1

        if (-not $manifest) {
            throw "ImportExcel.psd1 no encontrado"
        }

        Import-Module $manifest.FullName -ErrorAction Stop

        $data = @(
            [PSCustomObject]@{
                Name = "VM01"
                CPU = 4
                MemoryGB = 8
            },
            [PSCustomObject]@{
                Name = "VM02"
                CPU = 8
                MemoryGB = 16
            }
        )

        $path = Join-Path ([System.IO.Path]::GetTempPath()) `
            "test_importexcel.xlsx"

        $data | Export-Excel `
            -Path $path `
            -WorksheetName "VMs" `
            -BoldTopRow `
            -ErrorAction Stop

        if (-not (Test-Path $path)) {
            throw "No se genero el archivo Excel"
        }

        return "SUCCESS: ImportExcel genero $path"
    }
    catch {
        return "ERROR: $($_.Exception.Message)"
    }
}
