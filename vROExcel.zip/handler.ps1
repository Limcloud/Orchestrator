function Handler($context, $inputs) {

    try {
        $ErrorActionPreference = "Stop"

        # Buscar ImportExcel dentro del ZIP
        $manifest = Get-ChildItem `
            -Path $PSScriptRoot `
            -Filter "ImportExcel.psd1" `
            -Recurse |
            Select-Object -First 1

        if (-not $manifest) {
            throw "ImportExcel no encontrado"
        }

        Import-Module $manifest.FullName -ErrorAction Stop

        # Datos de prueba
        $data = @(
            [PSCustomObject]@{
                Name = "VM01"
                CPU = 4
                MemoryGB = 8
            },
            [PSCustomObject]@{
                Name = "VM02"
                CPU = 8
                MemoryGB = 16
            }
        )

        # Generar Excel
        $path = Join-Path `
            ([System.IO.Path]::GetTempPath()) `
            ("report_" + [guid]::NewGuid().ToString("N") + ".xlsx")

        try {
            $data | Export-Excel `
                -Path $path `
                -WorksheetName "VMs" `
                -BoldTopRow `
                -ErrorAction Stop

            # Convertir Excel a Base64
            $bytes = [System.IO.File]::ReadAllBytes($path)

            return [Convert]::ToBase64String($bytes)
        }
        finally {
            if (Test-Path $path) {
                Remove-Item $path -Force
            }
        }
    }
    catch {
        throw "Error generando Excel: $($_.Exception.Message)"
    }
}
